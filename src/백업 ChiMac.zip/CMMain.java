package ChiMac;

import java.util.Scanner;

public class CMMain {

	public static void main(String[] args) {
		CMDAO server = new CMDAO();
		CMDTO chimac = new CMDTO();
		
		Scanner sc = new Scanner(System.in);
		boolean run = true;
		boolean run1 = true; // 실행을 위한 boolean값 추가. 이후 정리
		boolean run1_1 = true;
		boolean run1_2 = true;
		boolean run1_3 = true;
		boolean run1_4 = true;
		int menu = 0;
		server.connect();
		
		System.out.println("오늘 치맥 어때?에 오신 것을 환영합니다.");
		System.out.println();
		
		while(run) {
			System.out.println("==============================");
			System.out.println("1.로그인 | 2.회원가입 | 3.종료");
			System.out.println("==============================");
			System.out.print("항목을 선택해주세요 >>");
			menu = sc.nextInt();
			
			switch(menu) {
			
			case 1 : //로그인
				
				System.out.print("아이디 입력 >> ");
				String cId = sc.next();
				
				System.out.print("비밀번호 입력 >> ");
				String cPw = sc.next();
				
				boolean check = server.idCheck(cId,cPw);
				
				if(check) {
					System.out.println("로그인 성공!");
					run1 = true;
				while(run1) {
					System.out.println("========================================================");
					System.out.println("1.검색      | 2.장바구니 확인 및 결제  | 3.계좌확인 ");
					System.out.println("4.게시판    | 5.회원정보 수정          | 6.회원정보 확인");
					System.out.println("7.회원탈퇴  | 8.로그아웃 ");
					System.out.println("========================================================");
					System.out.print("메뉴 선택 >> ");
					menu = sc.nextInt();
					
					switch(menu) {
					
					case 1 : //검색
						
						while(run1_1) {
							System.out.println("==================================");
							System.out.println("1.치킨 선택하기 | 2.맥주 선택하기 | 3.뒤로가기");
							System.out.println("==================================");
							System.out.print("메뉴 선택 >> ");
							menu = sc.nextInt();
							switch(menu) {
							case 1 : //치킨선택
								break;
							case 2 : //맥주선택
								break;
							case 3 : //뒤로가기
								run1_1 = false;
								break;
							default :
								System.out.println("다시 입력해주세요!");
								break;
							
							
							} //end case 1_1 switch
						} //end case 1_1 while
						
						break;
						
					case 2 : //장바구니 확인 및 결제
						
						while(run1_2) {
							System.out.println("===========================================");
							System.out.println("1.장바구니 확인 | 2.결제 | 3.장바구니 비우기 | 4.뒤로가기");
							System.out.println("===========================================");
							System.out.print("메뉴 선택 >> ");
							menu = sc.nextInt();
							
							switch(menu) {
							
							case 1 : //장바구니 확인
								break;
								
							case 2 : //결제
								break;
								
							case 3 : //장바구니 비우기
								break;
								
							case 4 : //뒤로가기
								run1_2 = false;
								break;
								
							default :
								System.out.println("다시 입력해주세요!");
								break;
							
							
							} //end case 1_2 switch
						} //end case 1_2 while
						
						break;
						
					case 3 : //계좌 확인
						
						while(run1_3) {
							System.out.println("==========================================");
							System.out.println("1.입금 | 2.출금 | 3.잔액조회  | 4.뒤로가기");
							System.out.println("==========================================");
							System.out.print("메뉴 선택 >> ");
							menu = sc.nextInt();
							
							switch(menu) {
							
							case 1 : //입금
								System.out.print("아이디 >> ");
								cId = sc.next();
								System.out.print("비밀번호 >> ");
								cPw = sc.next();
								
								boolean recheck = server.idCheck(cId,cPw);
								
								if(recheck) {
									System.out.print("입금액 >> ");
									int plusBalance = sc.nextInt();
								
									chimac.setCmId(cId);
									chimac.setCmPw(cPw);
									chimac.setCmBalance(plusBalance);
									server.deposit(chimac);
									break;
								} else {
									System.out.println("아이디와 비밀번호를 다시 확인해주세요.");
								}
								

								break;
							case 2 : //출금
								System.out.print("아이디 >> ");
								cId = sc.next();
								System.out.print("비밀번호 >> ");
								cPw = sc.next();
								recheck = server.idCheck(cId,cPw);
								
								if(recheck) {
									System.out.print("출금액 >> ");
									int minusBalance = sc.nextInt();
//									오류 지속됨. 구문 삭제									
//									int cBalance = server.checkBalance(cId);									
//									
//									DAO withdraw 2개로 나눠도 실패.
//									
//									if(minusBalance >= cBalance) {
//										server.withdraw(chimac,);
//									}


								    
								    
								    
								    
// 									해당 구간까지 삭제							    
									chimac.setCmId(cId);
									chimac.setCmPw(cPw);
									chimac.setCmBalance(minusBalance);
									server.withdraw(chimac);
									break;
								} else {
									System.out.println("아이디와 비밀번호를 다시 확인해주세요.");
								}

								
									
// 								int 값 출금쪽에 표시되어있었으나 구문 삭제로 잠시 이동
								
								break;
							case 3 : //잔액조회
								System.out.println("아이디 >> ");
								cId = sc.next();
								System.out.print("비밀번호 >> ");
								cPw = sc.next();
								recheck = server.idCheck(cId,cPw);
								
								if(recheck) {
									int cBalance = server.checkBalance(cId);
									System.out.println("잔액조회 : " + cBalance);
								} else {
									System.out.println("아이디와 비밀번호를 다시 확인해주세요.");
								}

								break;
								
							case 4 : //뒤로가기
								run1_3 = false;
								break;
		
							default :
								System.out.println("다시 입력해주세요!");
								break;
							
							
							} //end case 1_3 switch
						} //end case 1_3 while
						
						break;
						
					case 4 : //게시판
						
						while(run1_4) {
							System.out.println("==============================");
							System.out.println("1.리뷰조회   | 2.리뷰작성   | 3.리뷰수정");
							System.out.println("4.리뷰삭제   | 5.뒤로가기 ");
							System.out.println("==============================");
							System.out.print("메뉴 선택 >> ");
							menu = sc.nextInt();
							
							switch(menu) {
							
							case 1 : //리뷰조회
								break;
								
							case 2 : //리뷰작성
								System.out.println("100글자까지만 입력 가능합니다.");
								break;
								
							case 3 : //리뷰수정
								// 원하는 리뷰 선택 후
								System.out.println("100글자까지만 입력 가능합니다.");
								break;
								
							case 4 : //리뷰삭제
								break;
								
							case 5 : //뒤로가기
								run1_4 = false;
								break;
		
							default :
								System.out.println("다시 입력해주세요!");
								break;
							
							
							} //end case 1_4 switch
						} //end case 1_4 while
						
						break;
						
					case 5 : //회원정보수정
						System.out.println("수정할 회원정보를 입력해주세요!");
						
						System.out.print("수정할 회원 아이디 >> ");
						String cmId = sc.next();
						chimac.setCmId(cmId);
						
						System.out.print("비밀번호 >> ");
						String cmPw = sc.next();
						chimac.setCmPw(cmPw);
						
						System.out.print("이름 >> ");
						String cmName = sc.next();
						chimac.setCmName(cmName);
						
						System.out.print("생년월일 >> ");
						String cmBir = sc.next();
						chimac.setCmBir(cmBir);
						
						System.out.print("성별 >> ");
						String cmGen = sc.next();
						chimac.setCmGen(cmGen);
						
						System.out.print("이메일 >> ");
						String cmEmail = sc.next();
						chimac.setCmEmail(cmEmail);
						
						sc.nextLine();
						
						System.out.print("주소 >> ");
						String cmAdr = sc.nextLine();
						chimac.setCmAdr(cmAdr);
						
						System.out.print("전화번호 >> ");
						String cmPhone = sc.next();
						chimac.setCmPhone(cmPhone);
					
						
						break;
						
					case 6 : //회원정보확인
						System.out.print("아이디 입력 >> ");
						cId = sc.next();
						
						System.out.print("비밀번호 입력 >> ");
						cPw = sc.next();
						
						check = server.idCheck(cId,cPw);
						
						if(check) {
							server.memberList(cId);
						} else {
							System.out.println("아이디와 비밀번호가 일치하지 않습니다.");
						}
						
						break;
					
					case 7 : //회원탈퇴
						System.out.print("아이디 입력 >> ");
						cId = sc.next();
						
						System.out.print("비밀번호 입력 >> ");
						cPw = sc.next();
						
						check = server.idCheck(cId,cPw);
						
						if(check) {
							server.memberDelete(cId);
						} else {
							System.out.println("아이디와 비밀번호가 일치하지 않습니다.");
						}
						
						break;
						
					case 8 : //로그아웃
						run1 = false;
						System.out.println("로그아웃 되었습니다!");
						break;
						
					default :
						System.out.println("다시 입력해주세요!");
						break;
						
					
					} //end case1 switch
					
					
				} //end case1 while
				
				} else {  //end if문 (아이디 일치) else문 (아이디 불일치)
					System.out.println("아이디와 비밀번호가 일치하지 않습니다.");
				}
				break;
				
			case 2 : //회원가입
				System.out.println("회원정보를 입력해주세요!");
				
				System.out.print("아이디 >> ");
				String cmId = sc.next();
				chimac.setCmId(cmId);
				
				System.out.print("비밀번호 >> ");
				String cmPw = sc.next();
				chimac.setCmPw(cmPw);
				
				System.out.print("이름 >> ");
				String cmName = sc.next();
				chimac.setCmName(cmName);
				
				System.out.print("생년월일 >> ");
				String cmBir = sc.next();
				chimac.setCmBir(cmBir);
				
				System.out.print("성별 >> ");
				String cmGen = sc.next();
				chimac.setCmGen(cmGen);
				
				System.out.print("이메일 >> ");
				String cmEmail = sc.next();
				chimac.setCmEmail(cmEmail);
				
				sc.nextLine();
				
				System.out.print("주소 >> ");
				String cmAdr = sc.nextLine();
				chimac.setCmAdr(cmAdr);
				
				System.out.print("전화번호 >> ");
				String cmPhone = sc.next();
				chimac.setCmPhone(cmPhone);
				
				int cmBalance = 0;
				chimac.setCmBalance(cmBalance);
				
				chimac = new CMDTO(cmId, cmPw, cmName, cmBir, cmGen, cmEmail, cmAdr,
				cmPhone, cmBalance);
				server.memberJoin(chimac);
				
				break;
			case 3: // 종료
				run = false;
				System.out.println("종료 완료. 이용해주셔서 감사합니다.");
				break;
			default:
				System.out.println("항목 번호를 입력해주세요.");
				break;
			} // end switch
			
			
		} // end while
		server.conClose();

	}

}
